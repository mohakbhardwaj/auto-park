# auto-park
Official repository for MRSD'16 project - Auto Park for Social Robots
